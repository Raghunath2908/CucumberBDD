package com.cucumber.stepdefination;

import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import com.aventstack.extentreports.Status;
import com.cucumber.listener.Reporter;
import com.cucumber.test.ConfigReader;
import com.cucumber.test.HttpClient;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class StepDefinition {

	HttpClient http = new HttpClient();
	private final static Logger logger = Logger.getLogger(StepDefinition.class.getName());
	static String url;
	static String requestMethod;
	static String statusCode;
	static Response response;

	@Given("^User sets URL as \"([^\"]*)\" for retriving firmware config$")
	public void buildURL(String uri) {
		url = String.format("%s%s", ConfigReader.getWebPaHostName(), uri);
		Reporter.addStepLog(Status.PASS + " :: XCONF UI :: " + url);
		logger.info("URL:" + url);
	}

	@When("^User hits the API with \"([^\"]*)\" request method$")
	public void requestSubmission(String requestType) {
		RestAssured.baseURI = url;
		RequestSpecification request = RestAssured.given();
		request.headers("Content-Type", "application/json");
		response = request.get();
		Reporter.addStepLog(Status.PASS + ":: Response =  " + response.getBody().asString());
		logger.info("Response:" + response.getBody().asString());
	}

	@Then("^Verify the status code is (\\d+)$")
	public void verifyStatusCode(int responsecode) {
		statusCode = String.valueOf(response.getStatusCode());
		logger.info("Status code:" + statusCode);
		Assert.assertEquals(Integer.toString(responsecode), statusCode);
		Reporter.addStepLog(Status.PASS + ":: API Response Code  =  " + statusCode);
	}

	@And("^Validate the data$")
	public void validateReponseData() {
		String responseData = response.getBody().asString();
		logger.info(" Response Data =  " + response.getBody());
		JSONArray js = new JSONArray(responseData);
		for (int i = 0; i < js.length(); i++) {
			JSONObject obj = js.getJSONObject(i);
			Reporter.addStepLog("JSON Data =  " + obj);
			System.out.println(obj.get("id"));
		}

	}

}
