

import java.io.IOException;
import java.util.Properties;


public class ConfigReader {
	private static final String CONFIG_FILE = "config.properties";
	private static final Properties PROPERTIES = new Properties();
	static {
		try {
			PROPERTIES.load(ConfigReader.class.getClassLoader() 
					.getResourceAsStream(CONFIG_FILE));
		} catch (IOException e) {
			System.out.println("Config loading failed");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}	
	
	public static String getZeusHostName(){
		return PROPERTIES.getProperty("zeusHostName");
	}
	
	public static String getZeusVodRestUrl(){
		return PROPERTIES.getProperty("zeusVodRestUrl");
	}
	public static String getZeusPort(){
		return PROPERTIES.getProperty("zeusPort");
	}
	
	public static String getVodSampleXmlName(){
		return PROPERTIES.getProperty("vodSampleXmlName");
	}
	
	public static String getTitleURL(){
		return PROPERTIES.getProperty("TitleURL");
	}
	
	public static String getFalconIp() {
		return PROPERTIES.getProperty("falconCmIp");
		
	}
	
	public static String getFalconPort() {
		return PROPERTIES.getProperty("falconCmPort");
		
	}
	
	public static String getfalconCmContentIdUrl() {
		return PROPERTIES.getProperty("cmContentIdUrl");
		
	}
	
	public static String getfalconCmContentListUrl() {
		return PROPERTIES.getProperty("cmContentListUrl");
		
	}
	
/*	public static String getOfferURL(){
		return PROPERTIES.getProperty("OfferURL");
	}
	*/
	public static String getChannelDayURL(){
		return PROPERTIES.getProperty("channelDayURL");
	}
	
	public static String getClassificationURL() {
		return PROPERTIES.getProperty("classificationURL");
	}
	
	public static String getVcsStencilHostPort(){
		return PROPERTIES.getProperty("vcsStencilHostPort");
	}
	
	public static String getCiHostPort(){
		return PROPERTIES.getProperty("vcsCiHostPort");
	}
	
	public static String getServerClassPort(){
		return PROPERTIES.getProperty("Server_port");
	}
	
	public static String getDefaultPort(){
		return PROPERTIES.getProperty("Default_port");
	}
	
	public static String getUserName(){
		return PROPERTIES.getProperty("userName");
	}
	
	public static String getPassword(){
		return PROPERTIES.getProperty("password");
	}
	
	public static String getPath(){
		return PROPERTIES.getProperty("path");
	}
}
