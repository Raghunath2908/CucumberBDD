package com.cucumber.stepdefination;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;

import com.aventstack.extentreports.Status;
import com.cucumber.listener.Reporter;
import com.cucumber.test.ConfigReader;
import com.cucumber.test.HttpClient;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class StepDefinition {

	HttpClient http = new HttpClient();
	private final static Logger logger = Logger.getLogger(StepDefinition.class.getName());
	static String url;
	static String requestMethod;
	static String statusCode;
	static Response response;
	static String host;
	static String modelId;
	static String modelDesc;
	static String firmwareVersion;
	static String firmwareDescription;
	static String firmwareFileName;
	static String firmwareId;
	static String datatype;
	static String deviceName;
	static String deviceValue;

	@Given("^User sets URL as \"([^\"]*)\" for retriving firmware config$")
	public void buildURL(String uri) {
		url = String.format("%s%s", "http://" + ConfigReader.getXconfHostName() + ":" + ConfigReader.getXconfPort(),
				uri);
		Reporter.addStepLog(Status.PASS + " :: GET FIRMWARE CONFIG :: " + url);
		logger.info("URL:" + url);
	}

	@When("^User hits the API with \"([^\"]*)\" request method$")
	public void getRequestSubmission(String requestType) {
		RestAssured.baseURI = url;
		RequestSpecification request = RestAssured.given();
		request.headers("Content-Type", "application/json");
		response = request.get();
		Reporter.addStepLog(Status.PASS + ":: Response =  " + response.getBody().asString());
		logger.info("Response:" + response.getBody().asString());
	}

	@Then("^Verify the status code is (\\d+)$")
	public void verifyStatusCode(int responsecode) {
		statusCode = String.valueOf(response.getStatusCode());
		logger.info("Status code:" + statusCode);
		Assert.assertEquals(Integer.toString(responsecode), statusCode);
		Reporter.addStepLog(Status.PASS + ":: API Response Code  =  " + statusCode);
	}

	@And("^Validate the data$")
	public void validateReponseData() {
		String responseData = response.getBody().asString();
		logger.info(" Response Data =  " + response.getBody().asString());
		JSONArray js = new JSONArray(responseData);
		for (int i = 0; i < js.length(); i++) {
			JSONObject obj = js.getJSONObject(i);
			Reporter.addStepLog("JSON Data =  " + obj);
			System.out.println(obj.get("id"));
		}

	}

	@Given("^user should get the host details of Xconf$")
	public void getXconfHostDetails() {
		host = String.format("%s", "http://" + ConfigReader.getXconfHostName() + ":" + ConfigReader.getXconfPort());
		Reporter.addStepLog(Status.PASS + " :: XCONF URL :: " + host);
		logger.info("URL:" + host);
	}

	@When("^user should create a model \"([^\"]*)\" with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void createModel(String mUrl, String mId, String mDesc) {
		modelId = mId;
		modelDesc = mDesc;
		JSONObject reqBody = new JSONObject();
		reqBody.put("id", modelId);
		reqBody.put("description", modelDesc);
		url = String.format("%s%s", host, mUrl);
		RestAssured.baseURI = url;
		RequestSpecification request = RestAssured.given();
		request.headers("Content-Type", "application/json");
		request.body(reqBody.toString());
		Reporter.addStepLog(":: Request Body =  " + reqBody.toString());
		logger.info("Request Body:" + reqBody.toString());
		response = request.post();
	}

	@Then("^verify the response code \"([^\"]*)\"$")
	public void verifyResponseCode(String code) {
		statusCode = String.valueOf(response.getStatusCode());
		logger.info("Status code:" + statusCode);
		Assert.assertEquals(code, statusCode);
		Reporter.addStepLog(Status.PASS + ":: API Response Code  =  " + statusCode);
	}

	@When("^user hits the retrive model API \"([^\"]*)\" with modelid$")
	public void retriveModels(String mUrl) {
		url = String.format("%s%s%s", host, mUrl, modelId.toUpperCase());
		RestAssured.baseURI = url;
		RequestSpecification request = RestAssured.given();
		request.headers("Content-Type", "application/json");
		request.headers("Accept", "application/json");
		response = request.get();
		Reporter.addStepLog(Status.PASS + ":: API =  " + url);
		Reporter.addStepLog(":: Response =  " + response.getBody().asString());
		logger.info("Response:" + response.getBody().asString());
	}

	@Then("^validate modelid is created with modeldesc$")
	public void verifyModelResponseData() {
		Boolean status = false;
		String responseData = response.getBody().asString();
		logger.info(" Response Data =  " + response.getBody().asString());
		JSONObject obj = new JSONObject(responseData);
		Reporter.addStepLog("JSON Data =  " + obj);
		if (obj.get("id").equals(modelId.toUpperCase()) && obj.get("description").equals(modelDesc)) {
			Reporter.addStepLog(Status.PASS + ":: Response =  " + obj);
			status = true;
		}
		if (!status) {
			Reporter.addStepLog(Status.FAIL + "::Model ID and Model Description not Created");
			Assert.fail("Model ID and Model Description not Created");
		}
	}

	@When("^user should configure firmware \\\"([^\\\"]*)\\\" with modelid$")
	public void configureFirmware(String firmwareUrl, DataTable table) {
		url = String.format("%s%s", host, firmwareUrl);
		List<Map<String, String>> items = table.asMaps(String.class, String.class);
		for (Map<String, String> data : items) {
			firmwareDescription = data.get("Description");
			firmwareFileName = data.get("FileName");
			firmwareVersion = data.get("Version");
		}
		String jbody = createFirmWareJsonBody().toString();
		RestAssured.baseURI = url;
		RequestSpecification request = RestAssured.given();
		request.headers("Content-Type", "application/json");
		request.body(jbody);
		Reporter.addStepLog(":: URL =  " + url);
		Reporter.addStepLog(":: Request Body =  " + jbody);
		logger.info("Request Body:" + jbody);
		response = request.post();
	}

	@When("^user hits the retrieve firmware \"([^\"]*)\" with id$")
	public void retrieveFirmware(String fUrl) {
		url = String.format("%s%s%s", host, fUrl, firmwareId);
		Reporter.addStepLog(":: API =  " + url);
		RestAssured.baseURI = url;
		RequestSpecification request = RestAssured.given();
		request.headers("Content-Type", "application/json");
		response = request.get();
		Reporter.addStepLog(Status.PASS + ":: Response =  " + response.getBody().asString());
		logger.info("Response:" + response.getBody().asString());

	}

	@Then("^validate and verify the firmware config creation$")
	public void responseDataVerification() {
		Boolean status = false;
		String responseData = response.getBody().asString();
		logger.info(" Response Data =  " + response.getBody().asString());
		JSONObject obj = new JSONObject(responseData);
		if (obj.get("description").equals(firmwareDescription) && obj.get("firmwareFilename").equals(firmwareFileName)
				&& obj.get("firmwareVersion").equals(firmwareVersion)) {
			Reporter.addStepLog(Status.PASS + ":: Response =  " + obj);
			status = true;
		}
		if (!status) {
			Reporter.addStepLog(Status.FAIL + "::Firmware Configuration not Created");
			Assert.fail("Firmware Configuration not Created");
		}

	}

	@Given("^User sets URL as \"([^\"]*)\" to set parameter values or attributes for the given device$")
	public void prepareUrl(String uri) {
		host = String.format("%s%s%s", "http://" + ConfigReader.getWebPaHostName() + ":" + ConfigReader.getWebPaPort(),
				uri, "mac:" + ConfigReader.getDeviceMacAddr() + "/config");
		Reporter.addStepLog(Status.PASS + " :: WEBPA URL :: " + host);
		logger.info("URL:" + host);
	}

	@When("^user should set the values and hits the API with request method$")
	public void submitPatchRequest(DataTable table) {
		url = String.format("%s", host);
		List<Map<String, String>> items = table.asMaps(String.class, String.class);
		for (Map<String, String> data : items) {
			datatype = data.get("dataType");
			deviceName = data.get("name");
			deviceValue = data.get("value");
		}
		String body = createDeviceAttributesJsonBody().toString();
		RestAssured.baseURI = url;
		RequestSpecification request = RestAssured.given();
		request.header("Authorization", "Basic dXNlcjpwYXNz");
		request.body(body);
		Reporter.addStepLog(":: URL =  " + url);
		Reporter.addStepLog(":: Request Body =  " + body);
		logger.info("Request Body:" + body);
		response = request.patch();
	}

	@When("^user hits the retrieve API \"([^\"]*)\" to get the information about the added device$")
	public void getDeviceAttributeValues(String args) {
		url = String.format("%s%s%s", host, args, ConfigReader.getDeviceModelName());
		Reporter.addStepLog(":: API =  " + url);
		RestAssured.baseURI = url;
		RequestSpecification request = RestAssured.given();
		request.header("Authorization", "Basic dXNlcjpwYXNz");
		request.params("names", ConfigReader.getDeviceModelName());
		response = request.get();
		Reporter.addStepLog(Status.PASS + ":: Response =  " + response.getBody().asString());
		logger.info("Response:" + response.getBody().asString());
	}

	@Then("^validate and verify the attribute value of the device$")
	public void responseDatavalidation() {
		Boolean status = false;
		String responseData = response.getBody().asString();
		logger.info(" Response Data =  " + response.getBody().asString());
		JSONObject obj = new JSONObject(responseData);
		JSONArray jarr = new JSONArray(obj.get("parameters").toString());
		System.out.println(jarr);
		for (int i = 0; i < jarr.length(); i++) {
			JSONObject jobj = jarr.getJSONObject(i);
			if (obj.get("statusCode").toString().equals(statusCode) && jobj.get("message").toString().equals("Success")) {
				Reporter.addStepLog(Status.PASS + ":: Response =  " + obj);
				status = true;
			}
		}

		if (!status) {
			Reporter.addStepLog(Status.FAIL + "::Device not registered");
			Assert.fail("Device not registered");
		}

	}

	private JSONObject createFirmWareJsonBody() {
		JSONObject js = null;
		try {
			js = new JSONObject();
			firmwareId = "b65962b5-1481-4eed-a010-2abfa8c3bbfd";
			js.put("id", firmwareId);
			js.put("updated", "1440492963476");
			js.put("description", firmwareDescription);
			List<String> md = new ArrayList<String>();
			md.add(modelId.toUpperCase());
			js.put("supportedModelIds", md);
			js.put("firmwareDownloadProtocol", "tftp");
			js.put("firmwareFilename", firmwareFileName);
			js.put("firmwareVersion", firmwareVersion);
			js.put("rebootImmediately", false);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info(js.toString());
		return js;
	}

	private JSONObject createDeviceAttributesJsonBody() {
		JSONObject obj = new JSONObject();
		try {
			JSONObject jobj = new JSONObject();
			jobj.put("dataType", Integer.valueOf(datatype));
			jobj.put("name", deviceName);
			jobj.put("value", deviceValue);
			List<JSONObject> lst = new ArrayList<JSONObject>();
			lst.add(jobj);
			obj.put("parameters", lst);
			System.out.println(jobj);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(obj.toString());
		logger.info(obj.toString());
		return obj;
	}

}
