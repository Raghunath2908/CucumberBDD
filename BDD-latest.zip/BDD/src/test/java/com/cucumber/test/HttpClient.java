package com.cucumber.test;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.Scanner;
import java.util.logging.Logger;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONArray;
import org.junit.Assert;

public class HttpClient {

	static CloseableHttpClient httpClient = HttpClients.createDefault();
	private final static Logger logger = Logger.getLogger(HttpClient.class.getName());


	public static int httpPost(String appUrl, String jsonBody) {
		HttpResponse response = null;
		try {
			URI url = new URI(appUrl);
			HttpPost request = new HttpPost(url);
			StringEntity entity = new StringEntity(jsonBody);
			request.addHeader("content-type", "application/json");
			request.addHeader("Accept", "application/json");
			request.setEntity(entity);
			response = httpClient.execute(request);
			logger.info("Response Code = " + response.getStatusLine().getStatusCode());
			assertEquals(200, response.getStatusLine().getStatusCode());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return response.getStatusLine().getStatusCode();
	}

	public static int httpPatch(String appUrl, String jsonBody) {
		HttpResponse response = null;
		try {
			URI url = new URI(appUrl);
			HttpPatch request = new HttpPatch();
			StringEntity entity = new StringEntity(jsonBody);
			request.addHeader("content-type", "application/json");
			request.addHeader("Accept", "application/json");
			request.setEntity(entity);
			response = httpClient.execute(request);
			logger.info("Response Code = " + response.getStatusLine().getStatusCode());
			assertEquals(200, response.getStatusLine().getStatusCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response.getStatusLine().getStatusCode();
	}

	public static JSONArray httpGet(String appUrl) {
		JSONArray js = null;
		try {
			URI url = new URI(appUrl);
			HttpGet request = new HttpGet(url);
			request.addHeader("content-type", "application/json");
			request.addHeader("Accept", "application/json");
			HttpResponse response = httpClient.execute(request);
			logger.info("Response Code = " + response.getStatusLine().getStatusCode());
			Assert.assertEquals("Returned Status Code =%s " + (response.getStatusLine().getStatusCode()),
					response.getStatusLine().getStatusCode(), 200);
			String responseString = HttpClient.convertResponseToString(response);
			js = new JSONArray(responseString);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return js;
	}

	private static String convertResponseToString(HttpResponse response) throws IOException {
		InputStream responseStream = response.getEntity().getContent();
		Scanner scanner = new Scanner(responseStream, "UTF-8");
		String responseString = scanner.useDelimiter("\\Z").next();
		scanner.close();
		return responseString;
	}

}
