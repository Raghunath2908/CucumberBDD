package com.cucumber.test;

import java.io.IOException;
import java.util.Properties;

public class ConfigReader {
	private static final String CONFIG_FILE = "config.properties";
	private static final Properties PROPERTIES = new Properties();
	static {
		try {
			PROPERTIES.load(ConfigReader.class.getClassLoader().getResourceAsStream(CONFIG_FILE));
		} catch (IOException e) {
			System.out.println("Config loading failed");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	public static String getWebPaHostName() {
		return PROPERTIES.getProperty("webpaHost");
	}

	public static String getWebPaPort() {
		return PROPERTIES.getProperty("webpaPort");
	}

	public static String getXconfHostName() {
		return PROPERTIES.getProperty("xconfHost");
	}

	public static String getXconfPort() {
		return PROPERTIES.getProperty("xconfPort");
	}
	
	public static String getDeviceMacAddr() {
		return PROPERTIES.getProperty("macAddr");
	}
	
	public static String getDeviceModelName() {
		return PROPERTIES.getProperty("deviceModelName");
	}

}